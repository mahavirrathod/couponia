import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor() { }

  userIsLogin() { //toggle nav if user is loggedIn
    var token = localStorage.getItem('user_access_token');
    if (token == "user_logged_in") {
      return true;
  }
  }

  adminIsLogin() { //toggle nav if admin is loggedIn
    var token = localStorage.getItem('admin_access_token');
    if (token == "admin_logged_in") {
      return true;
  }
  }

  ngOnInit() {
    this.userIsLogin()
    this.adminIsLogin()
  }

  userLogout() {
    localStorage.removeItem('user_access_token'); //clear token
  }

  adminLogout() {
    localStorage.removeItem('admin_access_token'); //clear token
  }

}
