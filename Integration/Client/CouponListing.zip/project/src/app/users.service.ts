import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class UserService {

  constructor(private http: HttpClient) { }
  couponListUrl: string = 'http://localhost:3001/couponList';//URL that take data from nodejs and expressjs
  baseUrl: string = 'http://localhost:3001/';
  emailIdConcat: string = "email/";

  //To get list of all coupon
  getListOfCoupon() {
    return this.http.get<any>(this.couponListUrl); //returns complete list of coupons
  }

  //To get list of coupon by their category
  getListByCategoryOfCoupon(category) {
    return this.http.get<any>(this.baseUrl + category);
  }

  //To get list of coupon by their category
  getListByTypeOfCoupon(category) {
    return this.http.get<any>(this.baseUrl + "type/" + category);
  }

  //to save visitors emails into database
  setEmailId(emailId) {
    return this.http.get<any>(this.baseUrl + this.emailIdConcat + emailId);
  }

  //To add coupon in database
  addCoupon(employeeRecord) {
    return this.http.get<any>(this.baseUrl + "addRecord/" + JSON.stringify(employeeRecord));
  }

  //To get best offer coupon from database
  getBestOfferListOfCoupon() {
    return this.http.get<any>(this.baseUrl + "best");
  }

  //To check login of admin
  checkLogin() {
    return this.http.get<any>(this.baseUrl + "login");
  }

  //To add coupon in database
  removeCoupon(id) {
    return this.http.get<any>(this.baseUrl + "removeRecord/" + id);
  }

  //To get subscriber from database
  getSubscribedUser() {
    return this.http.get<any>(this.baseUrl + "getSubscribers/");
  }

  //To get subscriber from database
  getPosts() {
    return this.http.get<any>(this.baseUrl + "getPosts");
  }

  //To get subscriber from database
  getBlogByCategory(category) {
    return this.http.get<any>(this.baseUrl + "getPostsByCategory/" + category);
  }

  //To write post in database
  writePost(postContent) {
    return this.http.get<any>(this.baseUrl + "writePost/" + JSON.stringify(postContent));
  }

  //To write post in database
  userSignup(userData) {
    return this.http.get<any>(this.baseUrl + "userSignup/" + JSON.stringify(userData));
  }

  //To write post in database
  checkUserLogin(userRecord) {
    return this.http.get<any>(this.baseUrl + "userLogin/" + userRecord);
  }

  //To get post from database
  getPostByPostName(postName) {
    return this.http.get<any>(this.baseUrl + "getPost/" + postName);
  }

}
