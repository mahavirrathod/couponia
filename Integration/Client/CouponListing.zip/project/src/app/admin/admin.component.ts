import { Component, OnInit } from '@angular/core';
import { AmChartsService, AmChart } from "@amcharts/amcharts3-angular";

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  private chart: AmChart;
  constructor(private AmCharts: AmChartsService) { }

  ngOnInit() {
    //script file of Amcharts
    this.chart = this.AmCharts.makeChart( "chartdiv", {
      "type": "serial",
      "theme": "light",
      "dataProvider": [ {
        "country": "Food & Dining",
        "visits": 4.5
      }, {
        "country": "Fashion",
        "visits": 4.2
      }, {
        "country": "Recharge",
        "visits": 3.5
      }, {
        "country": "Beauty",
        "visits": 2.5
      }, {
        "country": "Mobiles",
        "visits": 4.5
      }, {
        "country": "Computers",
        "visits": 3.5
      }, {
        "country": "Gaming",
        "visits": 2.5
      }, {
        "country": "Home Decor",
        "visits": 4.5
      }, {
        "country": "TV",
        "visits": 4.3
      }, {
        "country": "Entertainment",
        "visits": 4.8
      } ],
      "valueAxes": [ {
        "gridColor": "#FFFFFF",
        "gridAlpha": 0.2,
        "dashLength": 0
      } ],
      "gridAboveGraphs": true,
      "startDuration": 1,
      "graphs": [ {
        "balloonText": "[[category]]: <b>[[value]]</b>",
        "fillAlphas": 0.8,
        "lineAlpha": 0.2,
        "type": "column",
        "valueField": "visits"
      } ],
      "chartCursor": {
        "categoryBalloonEnabled": false,
        "cursorAlpha": 0,
        "zoomable": false
      },
      "categoryField": "country",
      "categoryAxis": {
        "gridPosition": "start",
        "gridAlpha": 0,
        "tickPosition": "start",
        "tickLength": 20
      },
      "export": {
        "enabled": true
      }
    
    } );
  }

  
  logout() {
    localStorage.removeItem('admin_access_token'); //clear token
  }

  
}
