import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';


@Injectable()
export class UserAuthGuard implements CanActivate {

    base_url: string;

    constructor(private router: Router) { }


    canActivate() {
        // Check to see if a user has a valid token
        var token = localStorage.getItem('user_access_token');

        // check if token is set, then...
        if (token == "user_logged_in") {
            return true;
        }
        
        if (token == null) {
            // If not, then redirect them to the login page
            this.router.navigate(['/page-not-found']);
            return false;
        }
    }


}