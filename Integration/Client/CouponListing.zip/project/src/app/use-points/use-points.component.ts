import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-use-points',
  templateUrl: './use-points.component.html',
  styleUrls: ['./use-points.component.css']
})
export class UsePointsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  logout() {
    localStorage.removeItem('user_access_token');
  }
}
