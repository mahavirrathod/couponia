import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-premium-coupons',
  templateUrl: './premium-coupons.component.html',
  styleUrls: ['./premium-coupons.component.css']
})
export class PremiumCouponsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  logout() {
    localStorage.removeItem('user_access_token');
  }
}
