import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumCouponsComponent } from './premium-coupons.component';

describe('PremiumCouponsComponent', () => {
  let component: PremiumCouponsComponent;
  let fixture: ComponentFixture<PremiumCouponsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumCouponsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumCouponsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
