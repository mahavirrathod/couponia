import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-subscribed-user',
  templateUrl: './subscribed-user.component.html',
  styleUrls: ['./subscribed-user.component.css']
})
export class SubscribedUserComponent implements OnInit {

  
  constructor(private userService: UserService, private router: Router) { }
  users = []; //complete coupon list will come into this array

  ngOnInit() {
    this.userService.getSubscribedUser() //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array
      })
  }

  logout() {
    localStorage.removeItem('admin_access_token');
  }
}
