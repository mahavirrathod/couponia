import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import "angular2-navigate-with-data";
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {


    console.log(localStorage.getItem('access_token'));
  }

  formTitle: string = "Add Coupon";
  message = '';

  admin = {
    "_id": "5bb7088407102d1a5508a204",
    "name": "",
    "password": ""
  }

  logout() {
    localStorage.removeItem('admin_access_token'); //clear token
  }

  check() {
    if (this.admin.name == "" || this.admin.password == "") {
      this.message = "Please Fill all the Fields!";
    }
    else {
      this.userService.checkLogin()
        .subscribe(data => {
          var newVar = JSON.stringify(data);

          if (JSON.stringify(this.admin) === newVar.slice(1, -1)) {         //slice '[' and ']'
            localStorage.setItem('admin_access_token', "admin_logged_in");

            this.router.navigateByData({
              url: ["/admin"],
              data: '' //data - <any> type
            });
          }
          else {
            alert("Sorry Incorrect Credentials!")
          }
        })
    }
  }
}
