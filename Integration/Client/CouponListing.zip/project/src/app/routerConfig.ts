import { Routes } from '@angular/router';
import { ListComponent } from './list/list.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HelpComponent } from './help/help.component';
import { ListViewComponent } from './list-view/list-view.component';
import { ChartComponent } from './chart/chart.component';
import { AdminComponent } from './admin/admin.component';
import { TopBrandsComponent } from './top-brands/top-brands.component';
import { BestOffersComponent } from './best-offers/best-offers.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AddCouponComponent } from './add-coupon/add-coupon.component';
import { DeleteCouponComponent } from './delete-coupon/delete-coupon.component';
import { UpdateCouponComponent } from './update-coupon/update-coupon.component';
import { SubscribedUserComponent } from './subscribed-user/subscribed-user.component';
import { BlogComponent } from './blog/blog.component';
import { WritePostComponent } from './write-post/write-post.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserAreaComponent } from './user-area/user-area.component';
import { PremiumCouponsComponent } from './premium-coupons/premium-coupons.component';
import { GameComponent } from './game/game.component';
import { UsePointsComponent } from './use-points/use-points.component';
import { PostPageComponent } from './post-page/post-page.component';
import { UserAuthGuard } from './userAuth.guard';
import { ComingSoonComponent } from './coming-soon/coming-soon.component';

//To map routes
export const appRoutes:Routes = [
    {
        path:'home',
        component:HomeComponent
    },
    {
        path:'',
        component:HomeComponent
    },
    {
        path:'list',
        component:ListComponent
    },
    {
        path:'list-view',
        component:ListViewComponent
    },
    {
        path:'about',
        component:AboutComponent
    },
    {
        path:'contact',
        component:ContactComponent
    },
    {
        path:'help',
        component:HelpComponent
    },
    {
        path:'chart',
        component:ChartComponent
    },
    {
        path:'admin',
        canActivate: [AuthGuard],
        component:AdminComponent
    },
    {
        path:'top-brands',
        component:TopBrandsComponent
    },
    {
        path:'best-offers',
        component:BestOffersComponent
    },
    {
        path:'coming-soon',
        component:ComingSoonComponent
    },

    // admin part
    {
        path:'login',
        component:LoginComponent
    },
    {
        path:'page-not-found',
        component:PageNotFoundComponent
    },
    {
        path:'add-coupon',
        canActivate: [AuthGuard],
        component:AddCouponComponent
    },
    {
        path:'delete-coupon',
        canActivate: [AuthGuard],
        component:DeleteCouponComponent
    },
    {
        path:'update-coupon',
        canActivate: [AuthGuard],
        component:UpdateCouponComponent
    },
    {
        path:'subscribed-user',
        canActivate: [AuthGuard],
        component:SubscribedUserComponent
    },
    {
        path:'blog',
        component:BlogComponent
    },
    {
        path:'write-post',
        canActivate: [AuthGuard],
        component:WritePostComponent
    },
    {
        path:'post-page',
        component:PostPageComponent
    },

    //user part
    {
        path:'user-login',
        component:UserLoginComponent
    },
    {
        path:'user-signup',
        component:UserSignupComponent
    },
    {
        path:'user-area',
        canActivate: [UserAuthGuard],
        component:UserAreaComponent
    },
    {
        path:'premium-coupons',
        canActivate: [UserAuthGuard],
        component:PremiumCouponsComponent
    },
    {
        path:'game',
        canActivate: [UserAuthGuard],
        component:GameComponent
    },
    {
        path:'use-points',
        canActivate: [UserAuthGuard],
        component:UsePointsComponent
    },

    { path: '**', redirectTo: 'page-not-found' } //otherwise redirect to PageNotFound
]