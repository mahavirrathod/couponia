import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-coupon',
  templateUrl: './delete-coupon.component.html',
  styleUrls: ['./delete-coupon.component.css']
})
export class DeleteCouponComponent implements OnInit {

  users = []; //complete coupon list will come into this array
  constructor(private userService: UserService, private router: Router) { }

  message = "";
  ngOnInit() {
    this.userService.getListOfCoupon() //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array

      })
  }

  formTitle: string = "Remove Coupon";
  couponId = {
    "_id": ""
  }
  

  delete(id) {
    // console.log(id);
    this.userService.removeCoupon(id) //calls a function of users.service.ts
      .subscribe(data => {
        this.message = "Coupon Deleted"
        window.location.reload();
      })
  }
  logout() {
    localStorage.removeItem('admin_access_token'); //clear token
  }
}
