import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';

@Component({
  selector: 'app-write-post',
  templateUrl: './write-post.component.html',
  styleUrls: ['./write-post.component.css']
})
export class WritePostComponent implements OnInit {

  message = "";
  blog = {
    "name": "",
    "category": "",
    "content": "",
  }
  constructor(private userService: UserService) { }

  ngOnInit() {
  }


  write() {
    this.userService.writePost(this.blog)
      .subscribe(data => {
        this.message = "Post Published !"
        window.location.reload();
      })
  }

  logout() {
    localStorage.removeItem('admin_access_token');
  }
}
