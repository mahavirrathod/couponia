import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-page',
  templateUrl: './post-page.component.html',
  styleUrls: ['./post-page.component.css'],
  providers: [UserService]
})
export class PostPageComponent implements OnInit {
  
  constructor(private userService: UserService, private router: Router) { }

  blogPost = []; //post will come into this array

  getPost(a){ 
    this.userService.getPostByPostName(a) //get all posts by name
      .subscribe(data => {
        this.blogPost = data;
        console.log(data);
      })
  }

  ngOnInit() {
    let a = this.router.getNavigatedData();
    this.getPost(a);
  }


}