import { Component, OnInit } from '@angular/core';
import { AmChartsService, AmChart } from "@amcharts/amcharts3-angular";

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {

  private chart: AmChart;
  constructor(private AmCharts: AmChartsService) { }

//chart from Amcharts
  ngOnInit() {
    this.chart = this.AmCharts.makeChart( "chartdiv", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "title": "Food & Dining",
        "value": "5276"
      }, {
        "title": "Fashion",
        "value": 4746
      }, {
        "title": "Recharge",
        "value": 5154
      }, {
        "title": "Beauty & Health",
        "value": 6185
      }, {
        "title": "Mobiles & Tablets",
        "value": 5767
      }, {
        "title": "Computers",
        "value": 4671
      }, {
        "title": "Laptops & Gaming",
        "value": 4100
      }, {
        "title": "Home Furnishing & Decor",
        "value": 3943
      }, {
        "title": "TV/Audio/Video & Movies",
        "value": 5148
      }, {
        "title": "Entertainment",
        "value": 4812
      } ],
      "titleField": "title",
      "valueField": "value",
      "labelRadius": 5,
    
      "radius": "42%",
      "innerRadius": "60%",
      "labelText": "[[title]]",
      "export": {
        "enabled": true
      }
    } );
  }

}
