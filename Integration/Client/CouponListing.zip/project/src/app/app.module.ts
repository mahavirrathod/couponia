import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { appRoutes } from './routerConfig';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavComponent } from './nav/nav.component';
import { ListComponent } from './list/list.component';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './users.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HelpComponent } from './help/help.component';
import { ListViewComponent } from './list-view/list-view.component';
import { ChartComponent } from './chart/chart.component';
import { AmChartsModule } from "@amcharts/amcharts3-angular";
import { AdminComponent } from './admin/admin.component';
import { TopBrandsComponent } from './top-brands/top-brands.component';
import { BestOffersComponent } from './best-offers/best-offers.component';
import { LoginComponent } from './login/login.component';
import "angular2-navigate-with-data";
import { AuthGuard } from './auth.guard';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AddCouponComponent } from './add-coupon/add-coupon.component';
import { DeleteCouponComponent } from './delete-coupon/delete-coupon.component';
import { UpdateCouponComponent } from './update-coupon/update-coupon.component';
import { SubscribedUserComponent } from './subscribed-user/subscribed-user.component';
import { BlogComponent } from './blog/blog.component';
import { WritePostComponent } from './write-post/write-post.component';
import { PostPageComponent } from './post-page/post-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserAreaComponent } from './user-area/user-area.component';
import { PremiumCouponsComponent } from './premium-coupons/premium-coupons.component';
import { GameComponent } from './game/game.component';
import { UsePointsComponent } from './use-points/use-points.component';
import { UserAuthGuard } from './userAuth.guard';
import { ComingSoonComponent } from './coming-soon/coming-soon.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    ListComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    HelpComponent,
    ListViewComponent,
    ChartComponent,
    AdminComponent,
    TopBrandsComponent,
    BestOffersComponent,
    LoginComponent,
    PageNotFoundComponent,
    AddCouponComponent,
    DeleteCouponComponent,
    UpdateCouponComponent,
    SubscribedUserComponent,
    BlogComponent,
    WritePostComponent,
    PostPageComponent,
    UserLoginComponent,
    UserSignupComponent,
    UserAreaComponent,
    PremiumCouponsComponent,
    GameComponent,
    UsePointsComponent,
    ComingSoonComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    FormsModule,
    Ng2OrderModule,
    NgxPaginationModule,
    RouterModule.forRoot(appRoutes),
    AmChartsModule,
    
  ],

  providers: [UserService, AuthGuard, UserAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
