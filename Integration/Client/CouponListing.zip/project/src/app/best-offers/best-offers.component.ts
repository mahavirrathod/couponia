import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';

@Component({
  selector: 'app-best-offers',
  templateUrl: './best-offers.component.html',
  styleUrls: ['./best-offers.component.css']
})
export class BestOffersComponent implements OnInit {

    //sorting
    key: string = 'name';
    reverse: boolean = false;
  
    sort(key) {
      this.key = key;
      this.reverse = !this.reverse;
    }
  
  users = []; //complete coupon list will come into this array
  constructor(private userService:UserService) {}

  ngOnInit() {
      this.userService.getBestOfferListOfCoupon() //calls function of users.service.ts
        .subscribe(data => {
          this.users=data; //getting data into users array
          
        })
  }


}
