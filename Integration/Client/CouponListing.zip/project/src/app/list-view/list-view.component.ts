import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})

  export class ListViewComponent implements OnInit {

    //sorting
    key: string = 'name';
    reverse: boolean = false;
  
    sort(key) {
      this.key = key;
      this.reverse = !this.reverse;
    }
  
  users = []; //complete coupon list will come into this array
  constructor(private userService:UserService) {}

  ngOnInit() {
      this.userService.getListOfCoupon() //calls function of users.service.ts
        .subscribe(data => {
          this.users=data; //getting data into users array
          
        })
  }

  functionName(category){
    this.userService.getListByCategoryOfCoupon(category) //calls function of users.service.ts
    .subscribe(data=>{ 
      this.users = data; //getting data into users array
     })
  }

  typeFunction(category){
    this.userService.getListByTypeOfCoupon(category) //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array
      })
  }


}
