import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit() {
  }

  emailId = "";
  message = "";
  addEmail() {
    this.userService.setEmailId(this.emailId) //calls a function of users.service.ts
    .subscribe(data=>{ 
      this.message = "Subscribed successfully !";
     })
}
}
