import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  providers: [UserService]
})
export class ListComponent implements OnInit {

  //sorting
  key: string = 'review';
  reverse: boolean = false;

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  users = []; //complete coupon list will come into this array
  constructor(private userService: UserService, private router: Router) { }


  getAll() {
    this.userService.getListOfCoupon() //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array

      })
  }

  listByCategory(category) {
    this.userService.getListByCategoryOfCoupon(category) //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array
      })
  }

  typeFunction(category) {
    this.userService.getListByTypeOfCoupon(category) //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array
      })
  }

  ngOnInit() {
    //function to check if data is called from List page or from Home page
    let a = this.router.getNavigatedData();
    console.log(a);
    console.log(typeof a);
    if (typeof a == "string") //if getting data as string than it is called from Home page
      this.listByCategory(a);
    else //else print all
      this.getAll()

  }

}
