import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';

@Component({
  selector: 'app-add-coupon',
  templateUrl: './add-coupon.component.html',
  styleUrls: ['./add-coupon.component.css']
})
export class AddCouponComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit() {
  }

  message ="";
  min = 1500;
  max = 10000;
  formTitle:string= "Add Coupon";
  couponRecord={
    "_id" : 0,
    "name":"",
    "category":"",
    "used":"",
    "details":"",
    "reviews":"",
    "expires_on":"",
    "type":"",
    "code":""
  } //initializing an array


  add() {
    this.couponRecord._id = Math.floor(Math.random() * (this.max - this.min + 1)) + this.min;;
    this.userService.addCoupon(this.couponRecord) //calls a service in users.service.ts file
    .subscribe(data=>{ 
      this.message="Coupon Added !";
      window.location.reload();
     })
}
logout() {
  localStorage.removeItem('admin_access_token'); //clear token
}
}
