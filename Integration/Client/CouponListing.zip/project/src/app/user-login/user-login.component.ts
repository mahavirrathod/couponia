import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import "angular2-navigate-with-data";
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
  }

  message="";

  user = {
    "_id": "",
    "password": ""
  }

  userCheck() {
    if (this.user._id == "" || this.user.password == "") {
      this.message = "Please Fill all the Fields!";
    }
    else {
    this.userService.checkUserLogin(this.user._id)
      .subscribe(data => {

        var newVar = JSON.stringify(data);

        if (JSON.stringify(this.user) === newVar.slice(1, -1)) {

          localStorage.setItem('user_access_token', "user_logged_in");
          console.log(localStorage.getItem('user_access_token'));

          this.router.navigateByData({

            url: ["/user-area"],
            data: '' //data - <any> type

          });
        }
        else {
          alert("Sorry Incorrect Credentials!")
        }
      })
  }
}
}
