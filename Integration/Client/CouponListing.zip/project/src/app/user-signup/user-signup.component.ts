import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import "angular2-navigate-with-data";
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
  }

  message = "";
  repeatPassword = "";
  user = {
    "_id": "",
    "email": "",
    "contact": "",
    "password": ""
  }


  signup() {
    //check if all fields are filled
    if (this.user._id == "" || this.user.email == "" || this.user.contact == "" || this.user.password == "") {
      this.message = "Please Fill all the Fields!";
    }
    //check if password did not matched
    if (this.user.password != this.repeatPassword) {
      this.message = "Password didn't Matched"
    }
    if (this.user._id != "" && this.user.email != "" && this.user.contact != "" && this.user.password != "") {
      this.userService.userSignup(this.user)
        .subscribe(data => {
          this.router.navigateByData({

            url: ["/user-login"],
            data: '' //data - <any> type

          });
        })
    }
  }
}
