import { Component, OnInit } from '@angular/core';
import { UserService } from '../users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }
  users = []; //complete coupon list will come into this array

  ngOnInit() {
    this.userService.getPosts() //calls function of users.service.ts
      .subscribe(data => {
        this.users = data; //getting data into users array
      })
  }

  blogByCategory(category){
    this.userService.getBlogByCategory(category)
      .subscribe(data => {
        this.users = data;
        console.log(data);
      })
  }

  openPostPage(postName){
    
    this.router.navigateByData({

      url: ["/post-page"],
      data: postName 

    });
  }
}
