var express = require('express');

var app = express();

var cors = require('cors');

app.use(cors());

var bodyParser = require('body-parser');

var mongojs = require('mongojs');

var db = mongojs('coupon', ['code']);

app.use(express.static(__dirname));



// List all Coupon code

app.get('/couponList',
    function (req, res) {

        db.code.find({}, function (err, docs) {

            res.json(docs);

            console.log(docs);

        });

    });



// Get best offers from database i.e coupons which have mandatory 5 star reviews along with type as Free or 90% discount or Rs. 500 cash back

app.get('/best',
    function (req, res) {

        db.code.find({
            $and: [{ reviews: { $eq: 5 } }, {
                $or: [{
                    type: {
                        $eq:
                            "FREE"
                    }
                }, {
                    type: {
                        $eq:
                            "90% Discount"
                    }
                }, { type: { $eq: "Rs.500 Cash Off" } }]
            }]
        },
            function (err, docs) {

                res.json(docs);

                console.log(docs);

            });

    });



// Admin login check

app.get('/login',
    function (req, res) {

        db.login.find({}, function (err, docs) {

            res.json(docs);

            console.log(docs);

        });

    });



// List of coupon based on categories

app.get('/:id',
    function (req, res) {

        db.code.find({ category: { $eq: req.params.id } },
            function (err, docs) {

                res.json(docs);

                console.log(docs);

            });

    });



// Send subscribed emails

app.get('/email/:email',
    function (req, res) {

        var emailId = req.params.email;

        db.email.insert({ emailId });

        db.email.find({}, function (err, data) {

            res.send(data)

        });

    });



// Adding Record in MongoDB

app.get('/addRecord/:data',
    function (req, res) {

        // var max=3000,min=2000;

        // var randId= Math.random() * (max - min) + min;

        var data = JSON.parse(req.params.data);

        // data._id= randId;

        db.code.insert(data);

        db.code.find({}, function (err, data) {

            res.send(data)

        });

    })



    











//From here:

//user registration
app.get('/userSignup/:data',
    function (req, res) {
        var data = JSON.parse(req.params.data);
        db.users.insert(data);
        db.users.find({}, function (err, data) {
            res.send(data)
        });
    })

//user check login
app.get('/userLogin/:data',
    function (req, res) {
        db.users.find({_id:req.params.data},{_id:1,password:1}, function (err, data) {
            res.send(data)
        });
    })
app.listen(3001);
