var express = require('express');
var app = express();
var cors = require('cors');
app.use(cors());
var bodyParser = require('body-parser');
var mongojs = require('mongojs');
var db = mongojs('coupon',['code']);
app.use(express.static(__dirname));
app.get('/list', function(req,res) {
    db.code.find({},function(err, docs) {
        res.json(docs);
        console.log(docs);
    });
});
app.listen(3002);